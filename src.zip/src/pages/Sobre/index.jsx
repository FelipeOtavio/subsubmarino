import { useEffect, useState, useCallback } from "react";
import { formataValor } from "../../components/Main";
import { useHistory, Link } from "react-router-dom";

export const Sobre = () => {


    return(
        <>
            <h1 className="text-center">Sobre</h1>
            <div className="container">
                <p> Submarino é uma empresa brasileira de comércio eletrônico. Criada em 1999, foi uma das pioneiras do Brasil neste segmento. Em 2006, juntou-se com a Americanas.com, criando a B2W. É uma loja virtual oficializada pela Associação Brasileira dos Produtores de Discos e pela Federação Internacional da Indústria Fonográfica.</p>
            </div>
        </>
    )
}