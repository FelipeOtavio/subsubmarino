
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import { Routes } from './router';

function App() {
  return (
    <Routes></Routes>
  );
}

export default App;
