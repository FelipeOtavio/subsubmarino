export const Finalizar = () => {
    return(
        <>
            <h1 className="text-center">Finalizar Compra</h1>
        </>
    )
}