export const Erro = () => {
    return(
        <>
            <h1 className="text-center">Erro 404</h1>
        </>
    )
}